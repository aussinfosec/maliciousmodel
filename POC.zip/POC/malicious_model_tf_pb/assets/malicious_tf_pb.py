
#!/usr/bin/env python
import os
os.system('echo "Malicious code executed! (TF .pb)" > /tmp/malicious.txt')
with open('/tmp/eicar.com', 'w') as f:
    f.write('X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*')
